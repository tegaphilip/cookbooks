# Installs and configures the New Relic Infrastructure agent on Windows

raise 'Windows chef support for New Relic Infrastructure agent not yet available'
