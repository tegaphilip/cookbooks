default[:deploy]  = node[:deploy]
default[:apache2] = node[:apache2]
