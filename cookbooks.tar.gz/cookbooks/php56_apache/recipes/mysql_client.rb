package 'mysql-client' do
  action :install
end
