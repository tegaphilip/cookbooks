default[:deploy]  = node[:deploy]
