include_attribute 'initial_setup::default'

default[:deploy]  = node[:deploy]
