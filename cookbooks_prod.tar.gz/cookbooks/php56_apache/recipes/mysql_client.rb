#
# Cookbook:: php56_apache
# Recipe:: mysql_client
#
# Copyright:: 2017, The Authors, All Rights Reserved.

# Add the site configuration.

package 'mysql-client' do
  action :install
end
