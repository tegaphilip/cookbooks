#
# Cookbook:: build_cookbook
# Recipe:: functional
#
# Copyright:: 2017, The Authors, All Rights Reserved.
include_recipe 'delivery-truck::functional'
